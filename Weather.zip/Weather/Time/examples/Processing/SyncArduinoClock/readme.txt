SyncArduinoClock is a Processing sketch that responds to Arduino requests for 
time synchronization messages.

The portIndex must be set the Serial port connected to Arduino.

Download TimeSerial.pde onto Arduino and you should see the time 
message displayed when you run SyncArduinoClock in Processing.
The Arduino time is set from the time on your computer through the 
Processing sketch. 
