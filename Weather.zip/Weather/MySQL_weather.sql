CREATE TABLE weather (
    id INT NOT NULL AUTO_INCREMENT,
    wdate DATE NOT NULL,
    wtime TIME NOT NULL,
    tmstamp TIMESTAMP NOT NULL,
    Humidity SMALLINT NOT NULL,
    Temperature SMALLINT NOT NULL,
    HeatIndex SMALLINT NOT NULL,
    PRIMARY KEY ( id )
       );

CREATE TABLE test1 (
    id INT NOT NULL AUTO_INCREMENT,
    Temperature SMALLINT NOT NULL,
    tmstamp TIMESTAMP NOT NULL,
    PRIMARY KEY ( id )
       );



INSERT INTO weather (`Humidity`, `Temperature`, `HeatIndex`) VALUES ( t, h, hi, );

INSERT INTO weather (`wdate`, `wtime`, `Humidity`, `Temperature`, `HeatIndex`) VALUES ( now(), now(), 1, 2, 3 );

SELECT * FROM weather;

SELECT  `Humidity`, `Temperature`, `HeatIndex`+'%' FROM `weather`;

CREATE USER 'pi'@'192.168.18' IDENTIFIED BY 'Qomolangma11';
GRANT INSERT ON mcdermg_db.weather TO ‘pi’@'192.168.18';
FLUSH PRIVILEGES;



http://databaseblog.myname.nl/2013/01/how-to-install-mysql-succesfully-on.html


CREATE TABLE weather (id INT NOT NULL AUTO_INCREMENT,wdate DATE NOT NULL,wtime TIME NOT NULL,tmstamp TIMESTAMP NOT NULL,Humidity SMALLINT NOT NULL,Temperature SMALLINT NOT NULL,HeatIndex SMALLINT NOT NULL,PRIMARY KEY ( id ));



INSERT INTO `weather`.`test1` (`id`, `Temperature`, `tmstamp`) VALUES ('1', '12', CURRENT_TIMESTAMP);

INSERT INTO `weather`.`test1` (`Temperature`) VALUES ('22');

UPDATE test1 SET ID=1 WHERE ID = 5;

DELETE FROM test1 WHERE ID IN (1,2,3)

